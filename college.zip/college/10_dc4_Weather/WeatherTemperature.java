import java.io.IOException;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.*;
import org.apache.hadoop.mapreduce.*;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

public class WeatherTemperature {

    public static class TempMapper extends Mapper<LongWritable, Text, Text, IntWritable> {
        public void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
            String line = value.toString();

            if (!line.startsWith("year")) {
                String[] parts = line.split(",");
                if (parts.length >= 4) {
                    try {
                        String year = parts[0].trim();
                        int temp = Integer.parseInt(parts[3].trim());
                        context.write(new Text(year), new IntWritable(temp));
                    } catch (Exception e) {
                        // Ignore malformed lines
                    }
                }
            }
        }
    }

    public static class TempReducer extends Reducer<Text, IntWritable, Text, Text> {
        private String hottestYear = "";
        private String coldestYear = "";
        private double maxAvgTemp = Double.MIN_VALUE;
        private double minAvgTemp = Double.MAX_VALUE;

        public void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
            int sum = 0, count = 0;
            for (IntWritable val : values) {
                sum += val.get();
                count++;
            }

            double avg = (double) sum / count;
            context.write(new Text("Year: " + key.toString()), new Text("Avg Temp: " + String.format("%.2f", avg)));

            if (avg > maxAvgTemp) {
                maxAvgTemp = avg;
                hottestYear = key.toString();
            }

            if (avg < minAvgTemp) {
                minAvgTemp = avg;
                coldestYear = key.toString();
            }
        }

        protected void cleanup(Context context) throws IOException, InterruptedException {
            context.write(new Text("Hottest Year"), new Text(hottestYear + " (" + String.format("%.2f", maxAvgTemp) + "°)"));
            context.write(new Text("Coldest Year"), new Text(coldestYear + " (" + String.format("%.2f", minAvgTemp) + "°)"));
        }
    }

    public static void main(String[] args) throws Exception {
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "Weather Temperature Average");

        job.setJarByClass(WeatherTemperature.class);
        job.setMapperClass(TempMapper.class);
        job.setReducerClass(TempReducer.class);

        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);

        FileInputFormat.addInputPath(job, new Path(args[0]));    // e.g., /input/weather_data.csv
        FileOutputFormat.setOutputPath(job, new Path(args[1]));  // e.g., /output/weather_result

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
