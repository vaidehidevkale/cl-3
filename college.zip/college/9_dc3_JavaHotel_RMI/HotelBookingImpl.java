import java.rmi.server.UnicastRemoteObject;
import java.rmi.RemoteException;
import java.util.HashSet;

public class HotelBookingImpl extends UnicastRemoteObject implements HotelBooking {
    private HashSet<String> bookings;

    protected HotelBookingImpl() throws RemoteException {
        bookings = new HashSet<>();
    }

    public synchronized String bookRoom(String guestName) throws RemoteException {
        if (bookings.contains(guestName)) {
            return "Room is already booked for " + guestName;
        } else {
            bookings.add(guestName);
            return "Room successfully booked for " + guestName;
        }
    }

    public synchronized String cancelBooking(String guestName) throws RemoteException {
        if (bookings.contains(guestName)) {
            bookings.remove(guestName);
            return "Booking canceled for " + guestName;
        } else {
            return "No booking found for " + guestName;
        }
    }
}
