import java.rmi.Naming;
import java.util.Scanner;

public class HotelClient {
    public static void main(String[] args) {
        try {
            HotelBooking stub = (HotelBooking) Naming.lookup("rmi://localhost:2000/HotelService");

            Scanner scanner = new Scanner(System.in);
            while (true) {
                System.out.println("\n1. Book Room\n2. Cancel Booking\n3. Exit");
                System.out.print("Choose an option: ");
                int choice = scanner.nextInt();
                scanner.nextLine(); // Consume newline

                if (choice == 3) break;

                System.out.print("Enter guest name: ");
                String guestName = scanner.nextLine();

                if (choice == 1) {
                    System.out.println(stub.bookRoom(guestName));
                } else if (choice == 2) {
                    System.out.println(stub.cancelBooking(guestName));
                } else {
                    System.out.println("Invalid option.");
                }
            }
            scanner.close();
        } catch (Exception e) {
            System.out.println("Client Exception: " + e);
        }
    }
}
