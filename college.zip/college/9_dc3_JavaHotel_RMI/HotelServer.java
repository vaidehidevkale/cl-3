import java.rmi.Naming;
import java.rmi.registry.LocateRegistry;

public class HotelServer {
    public static void main(String[] args) {
        try {
            LocateRegistry.createRegistry(2000); // Start RMI registry
            HotelBookingImpl bookingService = new HotelBookingImpl();
            Naming.rebind("HotelService", bookingService);
            System.out.println("Hotel Booking Server is ready.");
        } catch (Exception e) {
            System.out.println("Server Exception: " + e);
        }
    }
}
